"""Instalación de la Tarea 1 v3 en Colab.

Solo usa la biblioteca estándar para no cargar en memoria ningún paquete antes de instalar.
Tres resultados posibles, cada uno con su mensaje:
- instalación lista: no hace falta reiniciar;
- instalación lista pero Colab tenía en memoria una versión que pip cambió: reinicio automático, una vez;
- pip falla: error real, con las últimas líneas del registro.
"""
import importlib.metadata as md
import os
import subprocess
import sys
from pathlib import Path

# Solo lo que Colab no trae o trae en otra versión. NumPy, pandas, SciPy y scikit-learn
# se usan tal como vienen en Colab: fijarlos obligaba a reiniciar casi siempre.
REQUISITOS = [
    "transformers==5.24.0",
    "sentence-transformers==6.1.0",
    "accelerate==1.11.0",
    "bitsandbytes==0.49.2",
]
MARCA = Path(".reinicio_tarea1_v3")


def _version(distribucion):
    try:
        return md.version(distribucion)
    except md.PackageNotFoundError:
        return None


def _distribuciones_en_memoria():
    """Versiones instaladas de los paquetes que ya están importados en esta sesión."""
    mapa = md.packages_distributions()
    nombres = {m.split(".")[0] for m in list(sys.modules)}
    distribuciones = {d for n in nombres for d in mapa.get(n, [])}
    return {d: _version(d) for d in distribuciones}


def _reiniciar():
    try:
        from IPython import get_ipython
        get_ipython().kernel.do_shutdown(restart=True)
    except Exception:
        os.kill(os.getpid(), 9)


def main():
    if sys.version_info < (3, 11):
        raise RuntimeError("Se necesita Python 3.11 o superior: abran un entorno de Colab nuevo.")
    if _version("torch") is None:
        raise RuntimeError("No encuentro PyTorch. Usen un entorno de Colab estándar con GPU T4.")

    antes = _distribuciones_en_memoria()
    print("Instalando dependencias (1 a 2 minutos)...")
    proceso = subprocess.run([sys.executable, "-m", "pip", "install", "-q", *REQUISITOS],
                             capture_output=True, text=True)
    if proceso.returncode != 0:
        registro = (proceso.stdout + "\n" + proceso.stderr).strip().splitlines()
        print("\n".join(registro[-25:]))
        raise RuntimeError("LA INSTALACIÓN FALLÓ. Esto sí es un problema: copien el mensaje de arriba "
                           "y escriban al equipo docente.")

    cambiados = sorted(d for d, v in antes.items() if _version(d) != v)
    if not cambiados:
        MARCA.unlink(missing_ok=True)
        print("Instalación lista. Continúen con la sección 2.")
        return

    if MARCA.exists():
        # Ya reiniciamos una vez y pip volvió a cambiar versiones: no reiniciar en bucle.
        raise RuntimeError("Ya se reinició una vez y las versiones siguen cambiando: " + ", ".join(cambiados)
                           + ". Escriban al equipo docente con este mensaje.")
    MARCA.write_text(", ".join(cambiados))
    print("Instalación lista. Colab tenía en memoria versiones anteriores de: " + ", ".join(cambiados) + ".")
    print("La sesión se reiniciará sola en unos segundos. Es normal y no borra archivos.")
    print("Cuando vuelva, continúen en la sección 2 (no hace falta volver a subir el paquete).")
    sys.stdout.flush()
    _reiniciar()


if __name__ == "__main__":
    main()
